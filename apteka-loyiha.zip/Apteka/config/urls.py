from django.contrib import admin
from django.contrib.auth.views import LoginView, LogoutView
from django.urls import include, path
from catalog.forms import UzbekAuthenticationForm

urlpatterns = [
    path("admin/", admin.site.urls),
    path("kirish/", LoginView.as_view(authentication_form=UzbekAuthenticationForm), name="login"),
    path("chiqish/", LogoutView.as_view(), name="logout"),
    path("", include("catalog.urls")),
]
