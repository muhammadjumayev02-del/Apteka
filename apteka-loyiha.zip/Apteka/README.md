# Apteka — Django dori katalogi

Python 3.10+ va Django 5.2.17. SQLite bilan bitta aptekaning ichki katalogi.
Tarkib va qo‘llanish matni avtomatik yaratilmaydi. Ularni vakolatli xodim rasmiy
yo‘riqnoma asosida kiritadi. Matn kiritilganda manba va tekshirilgan sana majburiy.
Manbaning haqiqiyligini tekshirish xodim zimmasida; sayt tashqi manbani yuklamaydi.

## Ishga tushirish

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py setup_roles
python manage.py seed_demo
python manage.py createsuperuser
python manage.py test
python manage.py runserver
```

Windows: `source .venv/bin/activate` o‘rniga `.venv\Scripts\activate`.
Sayt: http://127.0.0.1:8000/ — administrator: http://127.0.0.1:8000/admin/.
Boshlang‘ich migratsiya loyihaga qo‘shilgan. Model o‘zgarsa:
`python manage.py makemigrations catalog`, keyin `python manage.py migrate`.

## Xodimlar

Administrator `/admin/` orqali foydalanuvchi yaratadi, keyin uning guruhini belgilaydi:

- **Aptekachi**: dori qidirish va ko‘rish.
- **Vakolatli xodim**: katalogda dori qo‘shish, tahrirlash, joylashuv, narx va qoldiqni o‘zgartirish.

Ikkala guruh uchun ham `is_active` yoqilgan bo‘lsin. `is_staff` yoki `is_superuser`
kerak emas. Administratorga kirishi zarur bo‘lgan foydalanuvchiga alohida `is_staff`
belgilanishi mumkin. Oddiy foydalanuvchiga foydalanuvchilarni yoki guruhlarni
boshqarish ruxsatini bermang. Guruhsiz foydalanuvchiga katalog yopiq.

## Ishlash tartibi

- Qidiruv savdo nomi va faol moddalar bo‘yicha, 220 ms tanaffus bilan ishlaydi.
  JavaScript o‘chirilsa ham Qidirish tugmasi ishlaydi; bir sahifada 20 ta natija.
- Har bir joylashuvda bo‘lim, polka, qator va son saqlanadi. Jami qoldiq avtomatik hisoblanadi.
- Tahrirlash sahifasida “Yana joylashuv” bilan bir nechta joy qo‘shish mumkin.
  Joyni olib tashlash uchun o‘chirish belgisini qo‘yib saqlang. Kamida bitta joy kerak.
- Xayoliy namunalarda tarkib, qo‘llanish va rasmiy manba bo‘sh. Ular banner bilan ajratilgan.
  `seed_demo` takror ishga tushirilsa, mavjud namunalar o‘zgarmaydi.
- Tibbiy ma’lumot tekshirilgan sana alohida, yozuvning oxirgi yangilanish vaqti alohida saqlanadi.
- `search_text` oddiy `save()` orqali yangilanadi. Dorilarni `bulk_create` yoki
  `QuerySet.update()` bilan o‘zgartirmang: ular model validatsiyasi va qidiruv yangilanishini chetlab o‘tadi.

## Tekshiruv va chegaralar

`python manage.py test` qidiruv, sahifalash, Unicode, joylashuvlar, narx/qoldiqni
tahrirlash, tibbiy manba validatsiyasi, rollar, CSRF va HTML escapingni tekshiradi.
Interfeys mahalliy CSS/JS bilan ishlaydi; tashqi shrift yoki CDN talab qilinmaydi.

Bu dastlabki mahalliy SQLite loyiha. Ko‘p xodim bir vaqtda faol tahrirlasa PostgreSQL
va tahrirlar to‘qnashuvini aniqlash mexanizmini qo‘shish maqsadga muvofiq.
Internetga chiqarishda `DJANGO_DEBUG=0`, tasodifiy `DJANGO_SECRET_KEY`,
`DJANGO_ALLOWED_HOSTS`, HTTPS, WSGI server va static fayllarni xizmat qilishni sozlang;
`python manage.py collectstatic` va `python manage.py check --deploy`ni bajaring.
`runserver` mahalliy ishlab chiqish uchun.
