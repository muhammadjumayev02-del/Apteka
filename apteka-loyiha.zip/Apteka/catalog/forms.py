from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.forms import inlineformset_factory
from .models import Medicine, Placement


class UzbekAuthenticationForm(AuthenticationForm):
    username = forms.CharField(label="Foydalanuvchi nomi", widget=forms.TextInput(attrs={"autofocus": True}))
    password = forms.CharField(label="Parol", strip=False, widget=forms.PasswordInput)
    error_messages = {
        "invalid_login": "Foydalanuvchi nomi yoki parol noto‘g‘ri.",
        "inactive": "Bu hisob faol emas.",
    }


class MedicineForm(forms.ModelForm):
    class Meta:
        model = Medicine
        fields = ["name", "dosage", "form", "price", "active_ingredients", "indications",
                  "source", "reviewed_on", "is_demo"]
        widgets = {
            "reviewed_on": forms.DateInput(format="%Y-%m-%d", attrs={"type": "date"}),
            **{field: forms.Textarea(attrs={"rows": 3})
               for field in ["active_ingredients", "indications", "source"]},
        }


PlacementFormSet = inlineformset_factory(
    Medicine, Placement, fields=["department", "shelf", "row", "quantity"],
    extra=1, can_delete=True, min_num=1, validate_min=True,
    max_num=100, validate_max=True,
)
