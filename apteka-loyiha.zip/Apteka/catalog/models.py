import unicodedata
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models
from django.urls import reverse
from django.utils import timezone


def normalize(text):
    # SQLite uchun kirill, lotin va turli apostroflarni bir xilda qidirish.
    text = unicodedata.normalize("NFKC", text).casefold()
    return " ".join(text.translate(str.maketrans({c: "'" for c in "‘’ʻʼ`"})).split())


class Medicine(models.Model):
    name = models.CharField("Savdo nomi", max_length=180)
    dosage = models.CharField("Dozasi", max_length=80)
    form = models.CharField("Dori shakli", max_length=80)
    active_ingredients = models.TextField("Tarkibi / faol moddalar", blank=True)
    indications = models.TextField("Rasmiy yo‘riqnomaga ko‘ra qo‘llanishi", blank=True)
    source = models.TextField("Manba (yo‘riqnoma nomi, versiyasi yoki havola)", blank=True)
    reviewed_on = models.DateField("Tibbiy ma’lumot tekshirilgan sana", null=True, blank=True)
    price = models.DecimalField("Narxi (so‘m)", max_digits=12, decimal_places=2,
                                validators=[MinValueValidator(0)])
    is_demo = models.BooleanField("Xayoliy namuna", default=False)
    updated_at = models.DateTimeField("Oxirgi yangilanish", auto_now=True)
    search_text = models.TextField(editable=False)

    class Meta:
        ordering = ["name", "pk"]
        verbose_name = "Dori"
        verbose_name_plural = "Dorilar"
        constraints = [models.CheckConstraint(condition=models.Q(price__gte=0), name="price_nonnegative")]

    def __str__(self):
        return f"{self.name} · {self.dosage}"

    def get_absolute_url(self):
        return reverse("catalog:detail", args=[self.pk])

    def clean(self):
        errors = {}
        if self.active_ingredients.strip() or self.indications.strip():
            if not self.source.strip():
                errors["source"] = "Tibbiy ma’lumot uchun rasmiy manbani kiriting."
            if not self.reviewed_on:
                errors["reviewed_on"] = "Tekshirilgan sanani kiriting."
        if self.reviewed_on and self.reviewed_on > timezone.localdate():
            errors["reviewed_on"] = "Sana kelajakda bo‘lishi mumkin emas."
        if errors:
            raise ValidationError(errors)

    def save(self, *args, **kwargs):
        self.search_text = normalize(f"{self.name} {self.active_ingredients}")
        self.full_clean()
        if kwargs.get("update_fields") is not None:
            kwargs["update_fields"] = set(kwargs["update_fields"]) | {"search_text", "updated_at"}
        super().save(*args, **kwargs)


class Placement(models.Model):
    medicine = models.ForeignKey(Medicine, on_delete=models.CASCADE, related_name="placements")
    department = models.CharField("Bo‘lim", max_length=120)
    shelf = models.PositiveSmallIntegerField("Polka", validators=[MinValueValidator(1)])
    row = models.PositiveSmallIntegerField("Qator", validators=[MinValueValidator(1)])
    quantity = models.PositiveIntegerField("Mavjud soni", default=0)

    class Meta:
        ordering = ["department", "shelf", "row"]
        verbose_name = "Joylashuv"
        verbose_name_plural = "Joylashuvlar"
        constraints = [
            models.UniqueConstraint(fields=["medicine", "department", "shelf", "row"], name="unique_placement"),
            models.CheckConstraint(condition=models.Q(shelf__gte=1, row__gte=1), name="positive_coordinates"),
        ]

    def __str__(self):
        return f"{self.department} → {self.shelf}-polka → {self.row}-qator"
