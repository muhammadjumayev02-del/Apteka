from django.urls import path
from . import views

app_name = "catalog"
urlpatterns = [
    path("", views.home, name="home"),
    path("dorilar/yangi/", views.edit, name="create"),
    path("dorilar/<int:pk>/", views.detail, name="detail"),
    path("dorilar/<int:pk>/tahrirlash/", views.edit, name="edit"),
]
