from django.contrib import admin
from .models import Medicine, Placement


class PlacementInline(admin.TabularInline):
    model = Placement
    extra = 1
    min_num = 1
    validate_min = True


@admin.register(Medicine)
class MedicineAdmin(admin.ModelAdmin):
    list_display = ["name", "dosage", "form", "price", "is_demo", "updated_at"]
    search_fields = ["name", "active_ingredients"]
    list_filter = ["is_demo", "form"]
    readonly_fields = ["updated_at"]
    inlines = [PlacementInline]


admin.site.site_header = "Apteka boshqaruvi"
admin.site.site_title = "Apteka"
admin.site.index_title = "Boshqaruv paneli"
