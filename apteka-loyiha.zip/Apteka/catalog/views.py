from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_GET, require_http_methods
from .forms import MedicineForm, PlacementFormSet
from .models import Medicine, normalize


def medicines():
    return Medicine.objects.annotate(total=Sum("placements__quantity", default=0)).order_by("name", "pk")


@login_required
@permission_required("catalog.view_medicine", raise_exception=True)
@require_GET
def home(request):
    query = request.GET.get("q", "").strip()[:180]
    items = medicines()
    for word in normalize(query).split():
        items = items.filter(search_text__contains=word)
    page = Paginator(items, 20).get_page(request.GET.get("page"))
    template = "catalog/results.html" if request.GET.get("partial") == "1" else "catalog/home.html"
    return render(request, template, {"page_obj": page, "q": query})


@login_required
@permission_required("catalog.view_medicine", raise_exception=True)
@require_GET
def detail(request, pk):
    medicine = get_object_or_404(medicines().prefetch_related("placements"), pk=pk)
    return render(request, "catalog/detail.html", {"medicine": medicine})


@login_required
@permission_required([
    "catalog.view_medicine", "catalog.add_medicine", "catalog.change_medicine",
    "catalog.add_placement", "catalog.change_placement", "catalog.delete_placement",
], raise_exception=True)
@require_http_methods(["GET", "POST"])
def edit(request, pk=None):
    with transaction.atomic():
        medicine = get_object_or_404(Medicine.objects.select_for_update(), pk=pk) if pk else Medicine()
        form = MedicineForm(request.POST if request.method == "POST" else None, instance=medicine)
        placements = PlacementFormSet(request.POST if request.method == "POST" else None,
                                      instance=medicine, prefix="places")
        if request.method == "POST":
            valid_form = form.is_valid()
            valid_places = placements.is_valid()
            if valid_form and valid_places:
                form.save()
                placements.save()
                messages.success(request, "Dori ma’lumotlari saqlandi.")
                return redirect(medicine)
    return render(request, "catalog/edit.html", {"form": form, "placements": placements, "medicine": medicine})
