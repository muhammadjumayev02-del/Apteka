from django.contrib.auth.models import Group, Permission
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Aptekachi va Vakolatli xodim guruhlarini yaratadi."

    def handle(self, *args, **options):
        reader, _ = Group.objects.get_or_create(name="Aptekachi")
        reader.permissions.set(Permission.objects.filter(
            content_type__app_label="catalog", codename__in=["view_medicine", "view_placement"]))
        editor, _ = Group.objects.get_or_create(name="Vakolatli xodim")
        editor.permissions.set(Permission.objects.filter(content_type__app_label="catalog"))
        self.stdout.write(self.style.SUCCESS("Xodim guruhlari tayyor."))
